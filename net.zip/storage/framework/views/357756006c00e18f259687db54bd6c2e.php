<?php $__env->startSection('content'); ?>
    <div class="section search-result-wrap">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="heading" style="font-weight: bold">Category: <span
                            style="color: rgba(206, 245, 61, 0.8)"><?php echo e($kategoris->nama_kategori); ?></span> </div>
                </div>
            </div>
            <div class="row posts-entry">
                <div class="col-lg-8">
                    <?php $__currentLoopData = $kategoris->modul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="blog-entry d-flex blog-entry-search-item bg-light">
                            <a href="<?php echo e(route('user.modul', $modul->id_modul)); ?>" class="img-link me-4">
                                <img src="<?php echo e(asset('imgModul/' . $modul->gambar_modul)); ?>" alt="Image" class="img-fluid"
                                    style="max-width: 220px; max-height: 160px;">
                            </a>
                            <div>
                                <span><?php echo e($kategoris->nama_kategori); ?></span>
                                <h2><a href="<?php echo e(route('user.modul', $modul->id_modul)); ?>"><?php echo e($modul->nama_modul); ?></a></h2>
                                <p><a href="<?php echo e(route('user.modul', $modul->id_modul)); ?>" class="btn btn-sm btn-outline-primary bold">Read
                                        More</a></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <div class="col-lg-4 sidebar">
                    <div class="sidebar-box">
                        <h3 class="heading" style="font-weight: bold;">Categories</h3>
                        <ul class="categories">
                            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('user.kategori', $category->id_kategori)); ?>"
                                        style="color: black; text-decoration: none; "><?php echo e($category->nama_kategori); ?><span><?php echo e(count($category->modul)); ?></span></a>
                                </li>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appUtama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\framework\netcity\NetcityA\resources\views/pages/user/content/kategori.blade.php ENDPATH**/ ?>