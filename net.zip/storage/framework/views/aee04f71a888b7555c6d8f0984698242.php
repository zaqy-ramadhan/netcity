<footer class="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="widget">
                    <h3 class="mb-4" style="color: rgba(206, 245, 61, 0.8)">About Our Event</h3>
                    <p class="text-justify">NetCity is Networking With Creative Industry is a series of event consisting
                        of internationl seminars or workshops that invite mentors form the creative
                        industries as wll as creative exhibitions that aim to introduce the potential of the
                        creative industries</p>
                </div> <!-- /.widget -->
                <div class="widget">
                    
                </div> <!-- /.widget -->
            </div> <!-- /.col-lg-4 -->
            <div class="col-lg-4 ps-lg-5">
                <div class="widget">
                    
                    <h3 style="color: rgba(206, 245, 61, 0.8)">Social Media</h3>
                    <ul class="list-unstyled social">
                        <li><a href="https://www.instagram.com/netcitysurabaya/"><span
                                    class="icon-instagram"></span></a>
                        </li>
                        <li><a href="#"><span class="icon-twitter"></span></a></li>
                        <li><a href="#"><span class="icon-facebook"></span></a></li>
                        <li><a href="#"><span class="icon-linkedin"></span></a></li>
                        <li><a href="#"><span class="icon-pinterest"></span></a></li>
                        <li><a href="#"><span class="icon-dribbble"></span></a></li>
                    </ul>
                </div> <!-- /.widget -->
            </div> <!-- /.col-lg-4 -->

            <div class="col-lg-4">
                <div class="widget">
                    <h3 style="color: rgba(206, 245, 61, 0.8)">Join Event Group</h3>
                    <ul class="list-unstyled social">
                        <li><a href="#"><span class="icon-whatsapp"></span></a></li>
                        <li><a href="#"><span class="fab fa-line"></span></a></li>
                        <li><a href="#"><span class="icon-telegram"></span></a></li>
                    </ul>
                </div>
            </div> <!-- /.widget -->
        </div> <!-- /.col-lg-4 -->
    </div> <!-- /.row -->

    <div class="row mt-5">
        <div class="col-12">
            <p class="text-center">Copyright &copy;
                <script>
                    document.write(new Date().getFullYear());
                </script>. All Rights Reserved. &mdash; Designed with love by <span
                    style="color: rgba(206, 245, 61, 0.8)">NetInsight Team</span>
                Distributed by <a href="https://www.instagram.com/netcitysurabaya/"
                    style="color: rgba(206, 245, 61, 0.8);">NetCity Surabaya</a>
            </p>
        </div>
    </div>
    
    </div> <!-- /.container -->
</footer> <!-- /.site-footer -->
<?php /**PATH C:\xampp\htdocs\framework\netcity\NetcityA\resources\views/partials/user/footer.blade.php ENDPATH**/ ?>