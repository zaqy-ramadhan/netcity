<div class="site-mobile-menu site-navbar-target">
    <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close">
            <span class="icofont-close js-menu-toggle"></span>
        </div>
    </div>
    <div class="site-mobile-menu-body"></div>
</div>

<nav class="site-nav sticky-top">
    <div class="container">
        <div class="menu-bg-wrap">
            <div class="site-navigation">
                <div class="row g-0 align-items-center">
                    <div class="col-2">
                        <a href="<?php echo e(route('user.home')); ?>" class="logo m-0 float-start d-flex align-items-center">
                            <img src="<?php echo e(asset('images/LogoNetCity.png')); ?>" alt="Logo" style="max-width: 40px; height: auto; border-radius: 50%; margin-right: 10px; text-decoration: none;">
                            NETCITY<span class="text-primary">.</span>
                        </a>
                    </div>

                    <div class="col-8 text-right">
                        <ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
                            <li class="active"><a href="<?php echo e(route('user.home')); ?>">Home</a></li>
                            <li class="active"><a href="<?php echo e(route('user.ticketing')); ?>">Pesan Tiket</a></li>
                            <li class="has-children">
                                <a href="">Kategori Modul</a>

                                <ul class="dropdown">
                                    <?php $__currentLoopData = $categoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <li><a href="<?php echo e(route('user.kategori',$categori->id_kategori )); ?>" style="text-decoration: none"><?php echo e($categori->nama_kategori); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </li>
                        </ul>

                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li><a href=<?php echo e(route('login')); ?>>Login</a></li>
                                <li><a href=<?php echo e(route('register')); ?>>Register</a></li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="has-children"><a href="">Profile</a>
                                <ul class="dropdown">
                                    <li><a href="<?php echo e(route("pembayarans.index")); ?>" style="text-decoration: none">Pembayaran</a></li>
                                    <li><a href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a></li>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </div>
                    <div class="col-2 text-end">
                        <a href="#"
                            class="burger ms-auto float-end site-menu-toggle js-menu-toggle d-inline-block d-lg-none light">
                            <span></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\framework\netcity\NetcityA\resources\views/partials/user/navbar.blade.php ENDPATH**/ ?>